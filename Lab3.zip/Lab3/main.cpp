#include <iostream>
#include <string>
#include <vector>
#include <sstream>

#include "Relation.h"
#include "Scheme.h"
#include "Tuple.h"

using namespace std;

int main(int argc, char *argv[]) {

    vector<string> names;
    names.push_back("ID");
    names.push_back("Name");
    names.push_back("Major");

    Scheme scheme(names);
    Relation relation("student", scheme);

    vector<vector<string> > values;
    vector<string> names2;
    names2.push_back("42");
    names2.push_back("Ann");
    names2.push_back("CS");
    vector<string> names3;
    names3.push_back("32");
    names3.push_back("Bob");
    names3.push_back("CS");
    vector<string> names4;
    names4.push_back("64");
    names4.push_back("Ned");
    names4.push_back("EE");
    vector<string> names5;
    names5.push_back("16");
    names5.push_back("Jim");
    names5.push_back("EE");
    values.push_back(names2);
    values.push_back(names3);
    values.push_back(names4);
    values.push_back(names5);

  for (int i = 0; i < values.size(); i++) {
      Tuple tuple(values[i]);
      cout << tuple.toString(scheme) << endl;
      relation.addTuple(tuple);
  }

  cout << "relation: " << endl;
  cout << relation.toString();

  cout << endl;

  Relation result = relation.select(2, "CS");
  cout << "select Major='CS' result:" << endl;
  cout << result.toString();
   


}