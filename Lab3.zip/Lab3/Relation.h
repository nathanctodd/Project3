#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <set>
#include "Scheme.h"
#include "Tuple.h"

using namespace std;

class Relation {

    private:
        string name;
        Scheme mainScheme;
        set<Tuple> tuples;

    public:

        Relation(string inputName, Scheme inputScheme) {
            name = inputName;
            mainScheme = inputScheme;
        }

        void addTuple(const Tuple& tuple) {
            tuples.insert(tuple);
        }

        string toString() const {
            stringstream out;
            set<Tuple>::iterator itr;
            for (itr = tuples.begin(); itr != tuples.end(); itr++) {
                out << (*itr).toString(mainScheme) << endl;
            }
            return out.str();
        }

        Relation select(int index, const string& value) const {
            Relation result(name, mainScheme);
            set<Tuple>::iterator itr;
            for (itr = tuples.begin(); itr != tuples.end(); itr++) {
                if ((*itr).at(index) == value) {
                    result.addTuple((*itr));
                }
            }    
            return result;    
    }



};